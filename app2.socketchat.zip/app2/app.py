# Must be first
import eventlet
eventlet.monkey_patch()

from flask import Flask, render_template, request, jsonify, session, redirect, url_for, g
from flask_socketio import SocketIO, emit
import sqlite3
import os
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'supersecret'
app.config['DATABASE'] = os.path.join(app.root_path, 'database.db')

socketio = SocketIO(app, async_mode='eventlet', cors_allowed_origins="*")

# --- Database Helpers ---
def get_db():
    if 'db' not in g:
        g.db = sqlite3.connect(app.config['DATABASE'])
        g.db.row_factory = sqlite3.Row
    return g.db

def close_db(e=None):
    db = g.pop('db', None)
    if db is not None:
        db.close()

@app.teardown_appcontext
def teardown_db(exception):
    close_db(exception)

# --- Routes ---
@app.route('/')
def index():
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        db = get_db()
        user = db.execute("SELECT * FROM users WHERE username = ? AND password = ?", (username, password)).fetchone()
        if user:
            session['logged_in'] = True
            session['username'] = user['username']
            return redirect(url_for('dashboard'))
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

@app.route('/dashboard')
def dashboard():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    return render_template('dashboard.html', username=session['username'])

@app.route('/api/chat', methods=['GET', 'POST'])
def chat():
    db = get_db()
    if request.method == 'POST':
        data = request.get_json()
        sender = session.get('username')
        message = data.get('message')
        timestamp = datetime.utcnow().isoformat()
        db.execute("INSERT INTO chat (sender, message, timestamp) VALUES (?, ?, ?)", (sender, message, timestamp))
        db.commit()
        return jsonify({'status': 'success'})
    else:
        messages = db.execute("SELECT * FROM chat ORDER BY timestamp DESC LIMIT 50").fetchall()
        return jsonify([dict(row) for row in messages][::-1])

# --- WebSocket Event ---
@socketio.on('send_websocket_message')
def handle_websocket_message(data):
    username = session.get('username', 'Anonymous')
    message = data.get('message', '')
    db = get_db()
    db.execute('INSERT INTO chat (sender, message, timestamp) VALUES (?, ?, CURRENT_TIMESTAMP)', (username, message))
    db.commit()
    emit('new_websocket_message', {'sender': username, 'message': message}, broadcast=True)

if __name__ == '__main__':
    socketio.run(app, debug=True, host='127.0.0.1', port=5000)
